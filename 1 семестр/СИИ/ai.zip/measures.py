import json
import flask
# from fuzzywuzzy import fuzz
# from difflib import SequenceMatcher as SM
import Levenshtein
from chat import ChatAction, ChatActionType, TeaFilter, TeaSpeed, process_message


class TeaCat:
    def __init__(self, name, par) -> None:
        self.name = name
        self.par = par
        self.children = []
        if par is not None:
            par.children.append(self)


catRoot = TeaCat('root', None)
catSublim = TeaCat('Растворимый', catRoot)
catCustard = TeaCat('Заварной', catRoot)
catHerbal = TeaCat('Травяной', catCustard)
catTea = TeaCat('Чайный', catCustard)
catBlack = TeaCat('Чёрный', catTea)
catGreen = TeaCat('Зелёный', catTea)
catWhite = TeaCat('Белый', catTea)
catYellow = TeaCat('Жёлтый', catTea)
catOolong = TeaCat('Улун', catTea)
catPuer = TeaCat('Пуэр', catTea)

cats = {
    'root': catRoot,
    'Растворимый': catSublim,
    'Заварной': catCustard,
    'Травяной': catHerbal,
    'Чайный': catTea,
    'Чёрный': catBlack,
    'Зелёный': catGreen,
    'Белый': catWhite,
    'Жёлтый': catYellow,
    'Улун': catOolong,
    'Пуэр': catPuer,
}

elements = []


def read_node(node):
    cat = node['name']
    if node['leaf']:
        for elem in node['data']:
            extElem = elem.copy()
            extElem['cat'] = cat
            elements.append(extElem)
    else:
        for sub in node['data']:
            read_node(sub)


with open('./data.json', 'r') as f:
    data = json.load(f)
read_node(data)


def metricTemp(a, b):
    t1lo, t1hi = int(a['temp_lo']), int(a['temp_hi'])
    t2lo, t2hi = int(b['temp_lo']), int(b['temp_hi'])
    if t1lo > t2hi:
        return (t1lo - t2hi) / 100.0
    elif t2lo > t1hi:
        return (t2lo - t1hi) / 100.0
    else:
        return 0


def metricTime(a, b):
    return abs(a['prep_time'] - b['prep_time']) / 60.0


def _assocMetric(list1, list2):
    s1, s2 = set(list1), set(list2)
    return 1 - 2 * len(s1.intersection(s2)) / (len(s1) + len(s2))


def metricIngridients(a, b):
    return _assocMetric(a['ingridients'], b['ingridients'])


def metricTastes(a, b):
    return _assocMetric(a['tastes'], b['tastes'])


def metricPackageAndFlavor(a, b):
    res = 0
    if a['form'] != b['form']:
        res += 0.5
    if a['flavor'] != b['flavor']:
        res += 0.5
    return res


def metricTree(a, b):
    c1, c2 = cats[a['cat']], cats[b['cat']]

    if c1.name == c2.name:
        return 0

    anc1 = {}
    cur = c1
    cntr = 0
    while cur is not None:
        anc1[cur.name] = cntr
        cntr += 1
        cur = cur.par

    cur = c2
    cntr = 0
    while cur.name not in anc1.keys():
        cntr += 1
        cur = cur.par
        if cur is None:
            raise

    return (cntr + anc1[cur.name]) / 4.0


def metricAll(a, b):
    coeffs = {
        'temp': 0.3,
        'time': 0.3,
        'ingr': 1.0,
        'tastes': 1.0,
        'pandf': 0.05,
        'tree': 1.0,
    }
    return sum([
        coeffs['temp'] * metricTemp(a, b),
        coeffs['time'] * metricTime(a, b),
        coeffs['ingr'] * metricIngridients(a, b),
        coeffs['tastes'] * metricTastes(a, b),
        coeffs['pandf'] * metricPackageAndFlavor(a, b),
        coeffs['tree'] * metricTree(a, b),
    ]) / sum(coeffs.values())


def elById(id):
    for e in elements:
        if e['id'] == id:
            return e
    return None

# print(metricIngridients(elById(7), elById(8)))

# metric = metricTastes
# print('   ', end='')
# for b in elements:
#     print(f"{b['id']:7} ", end='')
# print()
# for a in elements:
#     print(f"{a['id']:2}: ", end='')
#     for b in elements:
#         print(f'{metric(a, b):6.3f}  ', end='')
#     print()

# def print_tea(tea):
#     def print_form(form_id):
#         return ["рассыпной", "в пакетиках", "брикет"][form_id - 1]
#     print(f"{tea['id']}. {tea['name']}: {tea['cat']} {print_form(tea['form'])}" +
#           f"{' с ароматизатором' if tea['flavor'] else ''} темп.:{tea['temp_lo']}-{tea['temp_hi']} " +
#           f"время: {tea['prep_time']}\n" +
#           f"    Состав: {tea['ingridients']}\n" +
#           f"    Вкусы: {tea['tastes']}")

# print_tea(elById(7))
# print_tea(elById(25))


def teaByFuzzyName(name):
    min_dist = 65535
    res = None
    for e in elements:
        cur = Levenshtein.distance(e['name'], name)
        if cur < min_dist:
            min_dist = cur
            res = e
    return res


def suggest_simmilar1(like_id):
    elt = elById(like_id)

    suggestions = []
    for e in elements:
        if e['id'] == like_id:
            continue
        suggestions.append((e, metricAll(elt, e)))

    suggestions.sort(key=lambda e: e[1])
    return suggestions


def suggest_simmilars(likes, dislikes):
    likedElts = [elById(e) for e in likes]
    disElts = [elById(e) for e in dislikes]

    suggestions = []
    for cand in elements:
        skip = False
        if cand['id'] in likes or cand['id'] in dislikes:
            continue

        res = 0
        for memb in likedElts:
            res += metricAll(cand, memb) / len(likes)
        for memb in disElts:
            metr = metricAll(cand, memb)
            if metr == 0:
                skip = True
                break
            res -= metr / len(dislikes)
        if skip:
            continue

        suggestions.append((cand, res))

    suggestions.sort(key=lambda e: e[1])
    return suggestions


def filter_table(table: list, filtf: TeaFilter):
    return list(filter(lambda x: not filtf.check(x), table))


def likes_dislikes(likes, dislikes, filters):
    res = []
    max_items = 10

    if len(likes) == 1 and len(dislikes) == 0:
        res = suggest_simmilar1(likes[0])
        res = [x[0] for x in res]
    elif len(likes) != 0 or len(dislikes) != 0:
        res = suggest_simmilars(likes, dislikes)
        res = [x[0] for x in res]

    orig_res = res

    if filters is not None:
        cat_filters = filters['cat']
        if cat_filters is not None:
            for filt in cat_filters:
                res = filter_table(res, TeaFilter.cat_filter_from_name(filt))

    if len(res) != 0:
        return {
            'filt_suggest': False,
            'data': res[:max_items],
        }
    else:
        return {
            'filt_suggest': True,
            'data': orig_res[:max_items],
        }


def filter_tea_time(teas, lo, hi):
    if lo is None: lo = -100000
    if hi is None: hi = +100000
    return list(filter(lambda x: lo <= x['prep_time'] <= hi, teas))


app = flask.Flask(__name__)


@app.route('/static/<path:path>')
def send_report(path):
    return flask.send_from_directory('reports', path)


@app.route('/all', methods=['GET'])
def all_route():
    raw_filters = flask.request.args.get('filters')

    res = elements

    if raw_filters is not None:
        filters = json.loads(raw_filters)
        cat_filters = filters.get('cat')
        if cat_filters is not None:
            for filt in cat_filters:
                res = filter_table(res, TeaFilter.cat_filter_from_name(filt))

    resp = flask.Response(json.dumps(res, separators=(',', ':')))
    resp.headers['Content-Type'] = 'application/json'
    return resp


@app.route('/likes_dislikes', methods=['GET'])
def likes_route():
    likes = json.loads(flask.request.args.get('likes'))
    dislikes = json.loads(flask.request.args.get('dislikes'))
    filters = flask.request.args.get('filters')
    if filters is not None:
        filters = json.loads(filters)

    res = likes_dislikes(likes, dislikes, filters)

    resp = flask.Response(json.dumps(res, separators=(',', ':')))
    resp.headers['Content-Type'] = 'application/json'
    return resp


table_all = True
chat_showed_smth = False
chat_likes = set([])
chat_dislikes = set([])
chat_filters = {
    "cat": [],
}
chat_timestamp = ''


@app.route('/chat_message', methods=['GET'])
def chat_route():
    global table_all
    global chat_showed_smth
    global chat_likes
    global chat_dislikes
    global chat_filters
    global chat_timestamp

    msg = flask.request.args.get('message')
    timestamp = flask.request.args.get('timestamp')

    if timestamp != chat_timestamp:
        print('New session')
        chat_likes = set([])
        chat_dislikes = set([])
        for k in chat_filters.keys():
            chat_filters[k] = []
        chat_timestamp = timestamp

    res_act = process_message(msg)
    res = {
        'upd_table': False,
        'teas': [],
        'message': 'Я не понимаю ;('
    }

    if res_act.type == ChatActionType.DONT_UNDERSTAND:
        res['message'] = 'Я не понимаю ;('

    elif res_act.type == ChatActionType.SHOW_SIMMILAR:
        for k in chat_filters.keys():
            chat_filters[k] = []

        guess = teaByFuzzyName(res_act.opt)
        chat_likes.add(guess['id'])
        ld = likes_dislikes(
            list(chat_likes), list(chat_dislikes), chat_filters)

        if not ld['filt_suggest']:
            res['message'] = f'Показываю похожие на {guess["name"]}'
        else:
            res['message'] = f'Похожих на {guess["name"]} чаёв, с учётом ваших предпочтений, нет. ' + \
                'Посмотрите на то, что может вас заинтересовать'
        res['upd_table'] = True
        res['teas'] = ld['data']
        chat_showed_smth = True

    elif res_act.type == ChatActionType.ADD_LIKE:
        guess = teaByFuzzyName(res_act.opt)
        chat_likes.add(guess['id'])
        ld = likes_dislikes(
            list(chat_likes), list(chat_dislikes), chat_filters)

        if not ld['filt_suggest']:
            res['message'] = f'Учитываю, что вам нравися {guess["name"]}'
        else:
            res['message'] = 'Чаёв, подходящих под ваши предпочтения нет. ' + \
                'Посмотрите на то, что может вас заинтересовать'
        res['upd_table'] = True
        res['teas'] = ld['data']
        chat_showed_smth = True

    elif res_act.type == ChatActionType.ADD_DISLIKE:
        guess = teaByFuzzyName(res_act.opt)
        chat_dislikes.add(guess['id'])
        ld = likes_dislikes(
            list(chat_likes), list(chat_dislikes), chat_filters)

        if not ld['filt_suggest']:
            res['message'] = f'Учитываю, что вам не нравися {guess["name"]}'
        else:
            res['message'] = 'Чаёв, подходящих под ваши предпочтения нет. ' + \
                'Посмотрите на то, что может вас заинтересовать'
        res['upd_table'] = True
        res['teas'] = ld['data']
        chat_showed_smth = True

    elif res_act.type == ChatActionType.ADD_FILTER:
        if not chat_showed_smth:
            res['message'] = f'Я вам ещё ничего не показал'
        else:
            chat_filters['cat'].append(res_act.opt.val)
            print(res_act.opt.val)
            ld = likes_dislikes(
                list(chat_likes), list(chat_dislikes), chat_filters)

            if not ld['filt_suggest']:
                res['message'] = f'Убираю из результатов {res_act.opt}'
            else:
                res['message'] = f'Убираю из результатов {res_act.opt}. ' \
                    'Чаёв, подходящих под ваши предпочтения нет. ' + \
                    'Посмотрите на то, что может вас заинтересовать'
            res['upd_table'] = True
            res['teas'] = ld['data']
            chat_showed_smth = True

    elif res_act.type == ChatActionType.SHOW_ALL:
        for k in chat_filters.keys():
            chat_filters[k] = []

        res['message'] = f'Показываю всё, что есть в наличии'
        res['teas'] = elements
        res['upd_table'] = True
        chat_showed_smth = True
        table_all = True

    elif res_act.type == ChatActionType.SHOW_SPEED:
        for k in chat_filters.keys():
            chat_filters[k] = []
        res_teas = elements

        if res_act.opt == TeaSpeed.QUICK:
            res_teas = filter_tea_time(res_teas, None, 60)
        elif res_act.opt == TeaSpeed.NOT_VERY_QUICK:
            res_teas = filter_tea_time(res_teas, 60, 90)
        elif res_act.opt == TeaSpeed.VERY_NOT_SLOW:
            res_teas = filter_tea_time(res_teas, 90, 105)
        elif res_act.opt == TeaSpeed.MEDIUM:
            res_teas = filter_tea_time(res_teas, 105, 400)
        elif res_act.opt == TeaSpeed.SLOW:
            res_teas = filter_tea_time(res_teas, 400, None)
        else:
            raise

        res['message'] = f'Показываю все чаи, которые завариваюстся {res_act.opt}'
        res['teas'] = res_teas
        res['upd_table'] = True
        chat_showed_smth = True
        table_all = True

    else:
        raise

    resp = flask.Response(json.dumps(res, separators=(',', ':')))
    resp.headers['Content-Type'] = 'application/json'
    return resp


app.run(host="0.0.0.0", port=3011)

# pip3 install -U pyweb
# pip install streamlit
# sudo pip install streamlit
# python3 -m pip install nicegui
