from enum import Enum
import re

import ply.lex as lex
import ply.yacc as yacc


class TeaSpeed:
    QUICK = 'быстро'
    SLOW = 'долго'
    VERY_NOT_SLOW = 'очень не долго'
    NOT_VERY_QUICK = 'не очень быстро'
    MEDIUM = 'средне'

    VERY_ = 100


class TeaFilter:
    FILT_CAT = 1

    CAT_BLACK = 'Чёрный'
    CAT_GREEN = 'Зелёный'
    CAT_YELLOW = 'Жёлтый'
    CAT_WHITE = 'Белый'
    CAT_OOLONG = 'Улун'
    CAT_PUER = 'Пуэр'
    CAT_HERBAL = 'Травяной'
    CAT_SUBLIM = 'Растворимый'

    def __init__(self, type, val) -> None:
        self.type = type
        self.val = val

    @staticmethod
    def cat_filter_from_name(name: str):
        if name == TeaFilter.CAT_BLACK:
            return TeaFilter(TeaFilter.FILT_CAT, TeaFilter.CAT_BLACK)
        elif name == TeaFilter.CAT_GREEN:
            return TeaFilter(TeaFilter.FILT_CAT, TeaFilter.CAT_GREEN)
        elif name == TeaFilter.CAT_YELLOW:
            return TeaFilter(TeaFilter.FILT_CAT, TeaFilter.CAT_YELLOW)
        elif name == TeaFilter.CAT_WHITE:
            return TeaFilter(TeaFilter.FILT_CAT, TeaFilter.CAT_WHITE)
        elif name == TeaFilter.CAT_OOLONG:
            return TeaFilter(TeaFilter.FILT_CAT, TeaFilter.CAT_OOLONG)
        elif name == TeaFilter.CAT_PUER:
            return TeaFilter(TeaFilter.FILT_CAT, TeaFilter.CAT_PUER)
        elif name == TeaFilter.CAT_HERBAL:
            return TeaFilter(TeaFilter.FILT_CAT, TeaFilter.CAT_HERBAL)
        elif name == TeaFilter.CAT_SUBLIM:
            return TeaFilter(TeaFilter.FILT_CAT, TeaFilter.CAT_SUBLIM)
        else:
            print(name)
            raise

    def check(self, tea: dict) -> bool:
        if self.type == TeaFilter.FILT_CAT:
            if tea['cat'] == self.val:
                return True
        else:
            return False

    def __str__(self) -> str:
        if self.type == TeaFilter.FILT_CAT:
            return {
                TeaFilter.CAT_BLACK: "чёрный чай",
                TeaFilter.CAT_GREEN: "зелёный чай",
                TeaFilter.CAT_YELLOW: "жёлтый чай",
                TeaFilter.CAT_WHITE: "белый чай",
                TeaFilter.CAT_OOLONG: "улуны",
                TeaFilter.CAT_PUER: "пуэры",
                TeaFilter.CAT_HERBAL: "травяной чай",
                TeaFilter.CAT_SUBLIM: "растворимый чай",
            }[self.val]
        else:
            return '<filter>'


class ChatActionType(Enum):
    DONT_UNDERSTAND = 1
    SHOW_SIMMILAR = 2
    ADD_LIKE = 3
    ADD_DISLIKE = 4
    ADD_FILTER = 5
    SHOW_ALL = 6
    SHOW_SPEED = 7


class ChatAction:
    def __init__(self, type: ChatActionType, opt=None) -> None:
        self.type = type
        self.opt = opt


# =======================================

tokens = (
    'CAN', 'SHOW', 'ME', 'PLEASE', 'INTERESTED', 'TEAS', 'SIMMILAR', 'TO', 'NAME_PART',
    'ALSO', 'LIKE', 'DONT', 'HATE', 'REMOVE', 'ALL', 'WHICH', 'BREWS',
    'BLACK', 'GREEN', 'YELLOW', 'WHITE', 'OOLONG', 'PUER', 'HERBAL', 'SUBLIM',
    'QUICK', 'MEDIUM', 'SLOW', 'VERY',
)

t_CAN = r'можешь|можете'
t_SHOW = r'покажи|покажите|показать|покажете'
t_ME = r'мне|меня|я'
t_PLEASE = r'пожалуйста'
t_INTERESTED = r'интересу(ют|ет)'
t_TEAS = r'чай|чаи'
t_SIMMILAR = r'похожи[йе]'
t_TO = r'(((((на)))))'
t_ALSO = r'ещ[её]'
t_LIKE = r'люблю|нрав[яи]тся|обожаю'
t_DONT = r'(((((не)))))'
t_HATE = r'ненавижу|отрицаю'
t_REMOVE = r'убрать|убери(те)?|удалить|удали(те)?|отфильровать|отфильруй(те)?'
t_ALL = r'вс[её]'
t_WHICH = r'которы[йе]'
t_BREWS = r'заварива[ею]ть?ся'


def t_QUICK(t):
    r'быстро'
    t.value = (t.value, TeaSpeed.QUICK)
    return t


def t_MEDIUM(t):
    r'средне'
    t.value = (t.value, TeaSpeed.MEDIUM)
    return t


def t_SLOW(t):
    r'долго|медленно'
    t.value = (t.value, TeaSpeed.SLOW)
    return t


def t_VERY(t):
    r'очень|сильно'
    t.value = (t.value, TeaSpeed.VERY_)
    return t


def t_BLACK(t):
    r'ч[её]рны[йе]'
    t.value = (t.value, TeaFilter.CAT_BLACK)
    return t


def t_GREEN(t):
    r'зел[её]ны[йе]'
    t.value = (t.value, TeaFilter.CAT_GREEN)
    return t


def t_YELLOW(t):
    r'ж[её]лты[йе]'
    t.value = (t.value, TeaFilter.CAT_YELLOW)
    return t


def t_WHITE(t):
    r'белы[йе]'
    t.value = (t.value, TeaFilter.CAT_WHITE)
    return t


def t_OOLONG(t):
    r'улуны?'
    t.value = (t.value, TeaFilter.CAT_OOLONG)
    return t


def t_PUER(t):
    r'пу[еэ]ры?'
    t.value = (t.value, TeaFilter.CAT_PUER)
    return t


def t_HERBAL(t):
    r'травяной|травяные'
    t.value = (t.value, TeaFilter.CAT_HERBAL)
    return t


def t_SUBLIM(t):
    r'растворимый|растворимые'
    t.value = (t.value, TeaFilter.CAT_SUBLIM)
    return t


t_NAME_PART = r'\S+'


def t_error(t):
    # print("Illegal character '%s'" % t.value[0])
    t.lexer.skip(1)


t_ignore = r' \r\n\t\f\.,\?!'


# ---


def p_msg(p):
    '''msg : show_simmilar
           | also_i_like_tea
           | also_i_hate_tea
           | can_you_remove_cat
           | show_all
           | show_speed'''
    p[0] = p[1]


def p_show_simmilar(p):
    '''show_simmilar : show_me TEAS SIMMILAR TO tea_name'''
    p[0] = ChatAction(ChatActionType.SHOW_SIMMILAR, p[5])


def p_also_i_like_tea(p):
    '''also_i_like_tea    : also_i_like tea_name'''
    p[0] = ChatAction(ChatActionType.ADD_LIKE, p[2])


def p_also_i_hate_tea(p):
    '''also_i_hate_tea    : also_i_hate tea_name'''
    p[0] = ChatAction(ChatActionType.ADD_DISLIKE, p[2])


def p_can_you_remove_cat(p):
    '''can_you_remove_cat   : can_you_remove cat_adj TEAS
                            | can_you_remove cat_noun'''
    p[0] = ChatAction(ChatActionType.ADD_FILTER, p[2])


def p_show_all(p):
    '''show_all : show_me ALL TEAS
                | show_me ALL'''
    p[0] = ChatAction(ChatActionType.SHOW_ALL)


def p_show_speed(p):
    '''show_speed   : show_me TEAS WHICH BREWS speed'''
    p[0] = ChatAction(ChatActionType.SHOW_SPEED, p[5])


def p_can_you_remove(p):
    '''can_you_remove   : CAN REMOVE
                        | CAN PLEASE REMOVE
                        | CAN REMOVE PLEASE
                        | REMOVE
                        | REMOVE PLEASE'''


def p_also_i_like(p):
    '''also_i_like  : ALSO ME LIKE
                    | ME LIKE
                    | ALSO ME LIKE TEAS
                    | ME LIKE TEAS'''


def p_also_i_hate(p):
    '''also_i_hate  : ALSO ME hate
                    | ME hate
                    | ALSO ME hate TEAS
                    | ME hate TEAS'''


def p_hate(p):
    '''hate     : DONT LIKE
                | HATE'''


def p_show_me(p):
    '''show_me  : SHOW
                | SHOW ME
                | CAN SHOW
                | CAN SHOW ME
                | show_me PLEASE'''


def p_cat_noun(p):
    '''cat_noun : OOLONG
                | PUER'''
    p[0] = TeaFilter(TeaFilter.FILT_CAT, p[1][1])


def p_cat_adj(p):
    '''cat_adj  : BLACK
                | GREEN
                | YELLOW
                | WHITE
                | HERBAL
                | SUBLIM'''
    p[0] = TeaFilter(TeaFilter.FILT_CAT, p[1][1])


def p_speed(p):
    '''speed    : QUICK
                | DONT VERY QUICK
                | VERY DONT SLOW
                | MEDIUM
                | SLOW'''
    if len(p) == 2:
        p[0] = p[1][1]
    else:
        if len(p[1]) == 3 and p[1] == TeaSpeed.VERY_:
            p[0] = TeaSpeed.VERY_NOT_SLOW
        else:
            p[0] = TeaSpeed.NOT_VERY_QUICK


def p_tea_name(p):
    '''tea_name : tea_name NAME_PART
                | tea_name TEAS
                | NAME_PART'''
    if len(p) == 2:
        p[0] = str(p[1])
    else:
        p[0] = str(p[1]) + ' ' + p[2]


lexer = lex.lex(reflags=re.UNICODE | re.DOTALL | re.IGNORECASE)
parser = yacc.yacc()


def parse_msg(message):
    # lexer.input(message)
    # while True:
    #     tok = lexer.token()
    #     if not tok:
    #         break
    #     print(tok)
    return parser.parse(message)


# =======================================


def process_message(msg: str) -> ChatAction:
    res = parse_msg(msg)
    if res is None:
        return ChatAction(ChatActionType.DONT_UNDERSTAND)
    return res
