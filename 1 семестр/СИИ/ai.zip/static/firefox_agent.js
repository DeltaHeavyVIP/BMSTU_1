const myhost = 'http://127.0.0.1:3011'

session_timestamp = Math.floor(Date.now() / 1000)

function add_cell(row, cl, val, action) {
    var cell = row.insertCell()
    cell.classList.add(cl)
    cell.appendChild(document.createTextNode(`${val}`))
}

function form_name(id) {
    switch (id) {
        case 1: return "Рассыпной";
        case 2: return "В пакетиках";
        case 3: return "Брикет";
        default: return "kill -9";
    }
}

function prettify_array(arr) {

    res = ""
    for (var i in arr) {
        res += arr[i].toString()
        if (i != arr.length - 1)
            res += ", "
    }
    return res
}

var liked_teas = new Set()
var disliked_teas = new Set()
var rows = []

function click_action(id, row) {
    if (liked_teas.has(id)) {
        row.style.backgroundColor = 'pink'
        liked_teas.delete(id)
        disliked_teas.add(id)
    }
    else if (disliked_teas.has(id)) {
        row.style.backgroundColor = ''
        disliked_teas.delete(id)
    }
    else {
        row.style.backgroundColor = 'lightgreen'
        liked_teas.add(id)
    }
}

function add_table_row(tbl, elts, no_actions) {
    var newRow = tbl.insertRow()

    add_cell(newRow, "table_col_id", elts['id'])
    add_cell(newRow, "table_col_name", elts['name'])
    add_cell(newRow, "table_col_cat", elts['cat'])
    add_cell(newRow, "table_col_package", form_name(elts['form']))
    add_cell(newRow, "table_col_flavor", elts['flavor'] ? "Да" : "Нет")
    add_cell(newRow, "table_col_temp", `${elts['temp_lo']}-${elts['temp_hi']}`)
    add_cell(newRow, "table_col_time", elts['prep_time'])
    add_cell(newRow, "table_col_ingrid", prettify_array(elts['ingridients']))
    add_cell(newRow, "table_col_tastes", prettify_array(elts['tastes']))

    if (!no_actions)
        newRow.onclick = () => click_action(parseInt(elts['id']), newRow)
    rows.push(newRow)
}

function clear_likes_dislikes() {
    liked_teas = new Set()
    disliked_teas = new Set()
    for (var e of rows) {
        e.style.backgroundColor = ''
    }
}

var tableRef = document.getElementById('active_tabs_tbl')

fetch(`${myhost}/all`)
    .then((response) => response.json())
    .then((data) => {
        for (var tea of data) {
            add_table_row(tableRef, tea, false)
        }
    })
    .catch((err) => console.error(err))

function get_filt_cats() {
    var res = []
    if (document.getElementById("filt_cat_black").checked)
        res.push('Чёрный')
    if (document.getElementById("filt_cat_green").checked)
        res.push('Зелёный')
    if (document.getElementById("filt_cat_yellow").checked)
        res.push('Жёлтый')
    if (document.getElementById("filt_cat_white").checked)
        res.push('Белый')
    if (document.getElementById("filt_cat_oolong").checked)
        res.push('Улун')
    if (document.getElementById("filt_cat_puer").checked)
        res.push('Пуэр')
    if (document.getElementById("filt_cat_herbal").checked)
        res.push('Травяной')
    if (document.getElementById("filt_cat_sublim").checked)
        res.push('Растворимый')
    return res
}

function clear_table(tbl) {
    var tableHeaderRowCount = 1
    var rowCount = tbl.rows.length
    for (var i = tableHeaderRowCount; i < rowCount; i++)
        tbl.deleteRow(tableHeaderRowCount)
    document.getElementById('no_match_message').hidden = true
}

function filter_all() {
    var res_table = document.getElementById('res_tbl')
    clear_table(res_table)
    const filters = {
        "cat": get_filt_cats(),
    }
    fetch(`${myhost}/all?filters=${encodeURIComponent(JSON.stringify(filters))}`)
        .then((response) => response.json())
        .then((data) => {
            if (data.length == 0) {
                document.getElementById('no_match_message').innerText = "Таких чаёв не существует"
                document.getElementById('no_match_message').hidden = false
                return
            }
            for (var tea of data) {
                add_table_row(res_table, tea, false)
            }
        })
        .catch((err) => console.error(err))
}

function simm() {
    var res_table = document.getElementById('res_tbl')
    clear_table(res_table)
    const filters = {
        "cat": get_filt_cats(),
    }
    const query =
        `${myhost}/likes_dislikes` +
        `?likes=[${Array.from(liked_teas)}]` +
        `&dislikes=[${Array.from(disliked_teas)}]` +
        `&filters=${encodeURIComponent(JSON.stringify(filters))}`
    fetch(query)
        .then((response) => response.json())
        .then((data) => {
            if (data['filt_suggest']) {
                document.getElementById('no_match_message').innerText =
                    "Подходящих чаёв не найдено. Возможно вам понравятся следующие чаи."
                document.getElementById('no_match_message').hidden = false
            }
            for (var tea of data['data']) {
                add_table_row(res_table, tea, true)
            }
        })
        .catch((err) => console.error(err))
}

function add_message(sender, text) {
    var msgs_list = document.getElementById('messages_list')

    var msg_div = document.createElement('div')
    var msg_name = document.createElement('div')
    var msg_text = document.createElement('div')

    msg_div.classList.add('msg_box')
    msg_text.classList.add('msg_text')
    msg_name.classList.add('msg_name')
    msg_name.appendChild(document.createTextNode(sender))
    msg_text.appendChild(document.createTextNode(text))

    msg_div.appendChild(msg_name)
    msg_div.appendChild(msg_text)
    msgs_list.appendChild(msg_div)
}

function send_ai_message() {
    var chat_input = document.getElementById('chat_input')
    if (chat_input.value == '')
        return
    add_message('Я', chat_input.value)

    const query =
        `${myhost}/chat_message` +
        `?timestamp=${session_timestamp}` +
        `&message=${encodeURIComponent(chat_input.value)}`
    fetch(query)
        .then((response) => response.json())
        .then((data) => {
            var res_table = document.getElementById('res_tbl')
            add_message('Бот', data['message'])
            if (data['upd_table']) {
                clear_table(res_table)
                for (var tea of data['teas']) {
                    add_table_row(res_table, tea, true)
                }
            }
        })
        .catch((err) => console.error(err))

    chat_input.value = ''
}

function chat_keyup(event) {
    if (event.keyCode == 13)
        send_ai_message()
}
